﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using eRunnerzProject.Control;
using System.Data;
using System.Data.SqlClient;

namespace eRunnerzProject
{
    public partial class ManageDesignation : System.Web.UI.UserControl
    {
        public int _designationMasterId;
        public bool _isEdit;

        public int DesignationMasterId
        {
            get { return _designationMasterId; }
            set { _designationMasterId = value; }
        }

        public bool IsEdit
        {
            get { return _isEdit; }
            set { _isEdit = value; }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(DesignationMasterId.ToString()))
            {
                string designationId = Request.Params["DesignationID"];
            }
            setADDFunction();
            btnSubmit.Text = "Submit";
            if (IsEdit)
            {
                btnSubmit.Text = "Update";
            }

        }
        private void setADDFunction()
        {
            SetWhoCanAddME();
            SetWhoCanIAdd();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Session["uid"]);
            string username = "";
            if (Session["Username"] == null)
            {
                DataTable dtAdminQuery = new DataTable();
                AdminQuery adminQuery = new AdminQuery();
                adminQuery.AdminId = id;
                dtAdminQuery = adminQuery.GetLoginUser(adminQuery);
                if (dtAdminQuery.Rows.Count > 0)
                {
                    username = Convert.ToString(dtAdminQuery.Rows[0]["Username"]);
                }
            }
            else
            {
                username = Convert.ToString(Session["Username"]);
            }
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            empQuery.DesignationName = txtDesignationName.Text;
            empQuery.DesignationCode = txtDEsignationCode.Text;
            empQuery.CheckDesignationIsValidOrNot(empQuery);
            DateTime serverTime = DateTime.Now; // gives you current Time in server timeZone
            DateTime utcTime = serverTime.ToUniversalTime(); // convert it to Utc using timezone setting of server computer

            TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime localTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, tzi); // convert from utc to local
            string date = String.Format("{0:yyyy-MM-dd}", localTime);
            string time = String.Format("{0:HH:mm:ss.fffffff}", localTime);
            TimeSpan intervalVal;
            TimeSpan ts = new TimeSpan();
            if (TimeSpan.TryParse(time, out intervalVal))
            {
                string intervalToStr = intervalVal.ToString();

                // Pad the end of the TimeSpan string with spaces if it 
                // does not contain milliseconds.
                int pIndex = intervalToStr.IndexOf(':');
                pIndex = intervalToStr.IndexOf('.', pIndex);
                if (pIndex < 0)
                    intervalToStr += "        ";
                ts = TimeSpan.Parse(intervalToStr);
            }
            DateTime Createddatetime = Convert.ToDateTime(date);

            string name = "";
            EmployeeDesignationQuery empDesignationQuery = new EmployeeDesignationQuery();
            empDesignationQuery.DesignationName = txtDesignationName.Text;
            empDesignationQuery.DesignationCode = txtDEsignationCode.Text;
            DataTable DesignationExist = empDesignationQuery.CheckDesignationIsValidOrNot(empDesignationQuery);
            if (DesignationExist.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(txtDEsignationCode.Text))
                {
                    if (DesignationExist.Rows[0]["DesignationCode"].ToString() == txtDEsignationCode.Text)
                    {
                        lblMessage.Text = "Designation Code<b> " + txtDEsignationCode.Text + " </b> is already exist";
                        return;
                    }
                }
                if (!string.IsNullOrEmpty(txtDEsignationCode.Text))
                {
                    if (DesignationExist.Rows[0]["DesignationName"].ToString() == txtDesignationName.Text)
                    {
                        lblMessage.Text = "Designation Name<b> " + txtDesignationName.Text + "</b> is already exist";
                        return;
                    }
                }
            }
            empQuery.CreatedById = id;
            empQuery.CreatedByName = username;
            empQuery.CreatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
            empQuery.CreatedOnActualTime = ts;
            empQuery.UpdatedById = id;
            empQuery.UpdatedByName = username;
            empQuery.UpdatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
            empQuery.UpdatedOnActualTime = ts;
            empQuery.isdelete = false;
            int newid = 0;
            newid = empQuery.InsertDesignation(empQuery,"");
            if (newid > 0)
            {
                foreach (ListItem item in chkWhoCanAddList.Items)
                {
                    if (item.Selected)
                    {
                        EmployeeAddPermissionQuery employeeAddPermissionQuery = new EmployeeAddPermissionQuery();
                        employeeAddPermissionQuery.DesignationMasterId = newid;
                        employeeAddPermissionQuery.WhocanADDMeDesignationID =Convert.ToInt32(item.Value);
                        employeeAddPermissionQuery.WhocanIADDDesignationID = 0;
                        employeeAddPermissionQuery.CreatedById = id;
                        employeeAddPermissionQuery.CreatedByName = username;
                        employeeAddPermissionQuery.CreatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.UpdatedById = id;
                        employeeAddPermissionQuery.UpdatedByName = username;
                        employeeAddPermissionQuery.UpdatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.SetEmployeeDesignationAddPermission(employeeAddPermissionQuery);
                    }
                }
                foreach (ListItem item in chkWhoCanIAdd.Items)
                {
                    if (item.Selected)
                    {
                        EmployeeAddPermissionQuery employeeAddPermissionQuery = new EmployeeAddPermissionQuery();
                        employeeAddPermissionQuery.DesignationMasterId = newid;
                        employeeAddPermissionQuery.WhocanADDMeDesignationID = 0;
                        employeeAddPermissionQuery.WhocanIADDDesignationID = Convert.ToInt32(item.Value);
                        employeeAddPermissionQuery.CreatedById = id;
                        employeeAddPermissionQuery.CreatedByName = username;
                        employeeAddPermissionQuery.CreatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.UpdatedById = id;
                        employeeAddPermissionQuery.UpdatedByName = username;
                        employeeAddPermissionQuery.UpdatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.SetEmployeeDesignationAddPermission(employeeAddPermissionQuery);
                    }
                }
                setADDFunction();

            }
            else
            {
                lblMessage.Text = "Sucessfully not updated";
            }

        }
        public void SetWhoCanAddME()
        {
            DataTable sql = new DataTable();
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            sql = empQuery.EmployeeDesignationList();
            if (sql.Rows.Count == 0)
            {
                pnlWhoCanADDMe.Visible = false;
                pnlWhoCanIAdd.Visible = false;
            }
            chkWhoCanAddList.Items.Clear();
            chkWhoCanAddList.RepeatDirection = RepeatDirection.Horizontal;
            foreach (DataRow row in sql.Rows) // Loop over the rows.
            {
                ListItem item = new ListItem();
                item.Text = row["DesignationName"].ToString();
                item.Value = row["DesignationId"].ToString();
                chkWhoCanAddList.Items.Add(item);
            }
        }
        public void SetWhoCanIAdd()
        {
            DataTable sql = new DataTable();
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            sql = empQuery.EmployeeDesignationList();
            chkWhoCanIAdd.Items.Clear();
            chkWhoCanIAdd.RepeatDirection = RepeatDirection.Horizontal;
            foreach (DataRow row in sql.Rows) // Loop over the rows.
            {
                ListItem item = new ListItem();
                item.Text = row["DesignationName"].ToString();
                item.Value = row["DesignationId"].ToString();
                chkWhoCanIAdd.Items.Add(item);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            DesignationList c1 =
                (DesignationList)LoadControl("DesignationList.ascx");
            pnlDesignationList.Controls.Add(c1);
            pnlDesignationList.Visible = true;
            pnlDesignationAdd.Visible = false;

        }

        protected void btnADD_Click(object sender, EventArgs e)
        {

        }
    }
}










