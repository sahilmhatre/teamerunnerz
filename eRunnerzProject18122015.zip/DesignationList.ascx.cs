﻿using eRunnerzProject.Control;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eRunnerzProject
{
    public partial class DesignationList : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindDesignationList();
            pnlDesignationList.Visible = true;

        }
        private void BindDesignationList()
        {
            DataTable dtEmployeeDesignation = new DataTable();
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            dtEmployeeDesignation = empQuery.EmployeeDesignationList();
            dlDesignationList.DataSource = dtEmployeeDesignation;
            dlDesignationList.DataBind();
            if (dlDesignationList.Items.Count == 0)
            {
                
            }

        }

        protected void dlDesignationList_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int SubjectID = Convert.ToInt32(dlDesignationList.DataKeys[e.Item.ItemIndex].ToString());
                ManageDesignation c1 =
           (ManageDesignation)LoadControl("ManageDesignation.ascx");
                c1.DesignationMasterId = SubjectID;
                c1._isEdit = true;
                pnlDesignation.Controls.Add(c1);
                pnlDesignationList.Visible = false;
            }
        }

        protected void ADDDesignation_Click(object sender, ImageClickEventArgs e)
        {
            ManageDesignation c1 =
       (ManageDesignation)LoadControl("ManageDesignation.ascx");
            c1._isEdit = false;
            pnlDesignation.Controls.Add(c1);
            pnlDesignationList.Visible = false;

        }
    }
}