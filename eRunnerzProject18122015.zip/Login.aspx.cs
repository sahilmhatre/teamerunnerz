﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using eRunnerzProject.Control;
using System.Data;

namespace eRunnerzProject
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "";
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            AdminQuery adminController = new AdminQuery();
            DataTable dt = new DataTable();
            adminController.Username = txtLogin.Text;
            adminController.UserPassword = txtPassword.Text;
            dt = adminController.AuthorizedUser(adminController);
            if (dt.Rows.Count > 0)
            {
                int id = Convert.ToInt32(dt.Rows[0]["AminID"]);
                Session["uid"] = id;
                Session["Username"] = txtLogin.Text;
                Response.Redirect("ManageDesignation.aspx?ID=" + id);
            }
            else
            {
                lblMessage.Text = "Invalid Username and Password!";
            } 
        }
    }
}