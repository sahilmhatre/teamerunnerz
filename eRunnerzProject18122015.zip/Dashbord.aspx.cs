﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using eRunnerzProject.Control;
using System.Data;
using System.Collections.Specialized;

namespace eRunnerzProject
{
    public partial class Dashbord : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["uid"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            if (string.IsNullOrEmpty(Request.QueryString["ID"]))
            {
                Response.Redirect("Login.aspx");
            }
            int id = Convert.ToInt32(Request.QueryString["ID"].ToString());
            DataTable dtAdminQuery = new DataTable();
            AdminQuery adminQuery = new AdminQuery();
            adminQuery.AdminId = id;
            dtAdminQuery = adminQuery.GetLoginUser(adminQuery);
            if (dtAdminQuery.Rows.Count > 0)
            {
                username.Text = Convert.ToString(dtAdminQuery.Rows[0]["Username"]);
                DesignationList c1 =
         (DesignationList)LoadControl("DesignationList.ascx");
                manageDesignation.Controls.Add(c1);
            }
        }
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Session.Remove("uid");
            Session["uid"] = null;
            Response.Redirect("Login.aspx");
        }
    }
}