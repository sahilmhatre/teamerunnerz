﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace eRunnerzProject.Control
{
    public class EmployeeDesignationController
    {
        string conn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        public int InsertDesignation(EmployeeDesignationQuery EmployeeDesignationQuery,string imagepath)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "AddDesignation";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DesignationName", EmployeeDesignationQuery.DesignationName);
                    cmd.Parameters.AddWithValue("@DesignationCode", EmployeeDesignationQuery.DesignationCode);
                    cmd.Parameters.AddWithValue("@CreatedById", EmployeeDesignationQuery.CreatedById);
                    cmd.Parameters.AddWithValue("@CreatedByName", EmployeeDesignationQuery.CreatedByName);
                    cmd.Parameters.AddWithValue("@CreatedOnActualDate", EmployeeDesignationQuery.CreatedOnActualDate);
                    cmd.Parameters.AddWithValue("@CreatedOnActualTime", EmployeeDesignationQuery.CreatedOnActualTime);
                    cmd.Parameters.AddWithValue("@UpdatedById", EmployeeDesignationQuery.UpdatedById);
                    cmd.Parameters.AddWithValue("@UpdatedByName", EmployeeDesignationQuery.UpdatedByName);
                    cmd.Parameters.AddWithValue("@LastUpdatedOnDate", EmployeeDesignationQuery.UpdatedOnActualDate);
                    cmd.Parameters.AddWithValue("@LastUpdatedOnTime", EmployeeDesignationQuery.UpdatedOnActualTime);
                    cmd.Parameters.AddWithValue("@IsDeleted", EmployeeDesignationQuery.isdelete);
                    cmd.Parameters.AddWithValue("@DesignationImage", imagepath);
                    cmd.Parameters.Add("@newidentity", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.Connection = sqlCon;
                    try
                    {
                        sqlCon.Open();
                        cmd.ExecuteNonQuery();
                        int id = Convert.ToInt32(cmd.Parameters["@newidentity"].Value);
                        return id;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }

                }
            }
        }
        public bool DeleteDesignation(string  selectedDesignationID)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "DeleteDesignation";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DesignationId", selectedDesignationID);
                    cmd.Connection = sqlCon;
                    try
                    {
                        sqlCon.Open();

                        return cmd.ExecuteNonQuery() > 0;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }

                }
            }
        }
        public bool UpdateDesignation(EmployeeDesignationQuery EmployeeDesignationQuery,string imagepath)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "UpdateDesignation";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DesignationName", EmployeeDesignationQuery.DesignationName);
                    cmd.Parameters.AddWithValue("@DesignationCode", EmployeeDesignationQuery.DesignationCode);
                    cmd.Parameters.AddWithValue("@UpdatedById", EmployeeDesignationQuery.UpdatedById);
                    cmd.Parameters.AddWithValue("@UpdatedByName", EmployeeDesignationQuery.UpdatedByName);
                    cmd.Parameters.AddWithValue("@LastUpdatedOnDate", EmployeeDesignationQuery.UpdatedOnActualDate);
                    cmd.Parameters.AddWithValue("@LastUpdatedOnTime", EmployeeDesignationQuery.UpdatedOnActualTime);
                    cmd.Parameters.AddWithValue("@IsDeleted", EmployeeDesignationQuery.isdelete);
                    cmd.Parameters.AddWithValue("@DesignationImage", imagepath);
                    cmd.Parameters.AddWithValue("@DesignationId", EmployeeDesignationQuery.DesignationId);
                    cmd.Connection = sqlCon;
                    try
                    {
                        sqlCon.Open();
                        return cmd.ExecuteNonQuery() > 0;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }

        public DataTable CheckDesignationIsValidOrNot(EmployeeDesignationQuery employeeDesignationQuery)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "CheckDesignationIsValidOrNot";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DesignationCode", employeeDesignationQuery.DesignationCode);
                    cmd.Parameters.AddWithValue("@DesignationName", employeeDesignationQuery.DesignationName);
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        return dt;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }

        public DataTable GetDesignationListByDesignationId(EmployeeDesignationQuery employeeDesignationQuery)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "GetDesignationListByDesignationId";
                    cmd.Parameters.AddWithValue("@designationID", employeeDesignationQuery.DesignationId);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        return dt;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }
        public DataTable GetDesignationAddMasterListByDesignationId(EmployeeAddPermissionQuery employeeAddPermissionQuery)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "GetDesignationAddMasterListByDesignationId";
                    cmd.Parameters.AddWithValue("@designationID", employeeAddPermissionQuery.DesignationMasterId);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        return dt;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }
        public DataTable EmployeeDesignationList()
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "SelectEmployeeDesignation";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        return dt;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }
        public bool SetEmployeeDesignationAddPermission(EmployeeAddPermissionQuery employeeAddPermissionQuery)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "InsertIntoDesignationAddPermission";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DesignationMasterId", employeeAddPermissionQuery.DesignationMasterId);
                    cmd.Parameters.AddWithValue("@WhocanIADDDesignationID", employeeAddPermissionQuery.WhocanIADDDesignationID);
                    cmd.Parameters.AddWithValue("@WhocanADDMeDesignationID", employeeAddPermissionQuery.WhocanADDMeDesignationID);
                    cmd.Parameters.AddWithValue("@CreatedById", employeeAddPermissionQuery.CreatedById);
                    cmd.Parameters.AddWithValue("@CreatedByName", employeeAddPermissionQuery.CreatedByName);
                    cmd.Parameters.AddWithValue("@CreatedOnActualDate", employeeAddPermissionQuery.CreatedOnActualDate);
                    cmd.Parameters.AddWithValue("@CreatedOnActualTime", employeeAddPermissionQuery.CreatedOnActualTime);
                    cmd.Parameters.AddWithValue("@UpdatedById", employeeAddPermissionQuery.UpdatedById);
                    cmd.Parameters.AddWithValue("@UpdatedByName", employeeAddPermissionQuery.UpdatedByName);
                    cmd.Parameters.AddWithValue("@UpdatedOnDate", employeeAddPermissionQuery.UpdatedOnActualDate);
                    cmd.Parameters.AddWithValue("@UpdatedOnTime", employeeAddPermissionQuery.UpdatedOnActualTime);
                    cmd.Parameters.AddWithValue("@IsDeleted", employeeAddPermissionQuery.isdeleted);
                    cmd.Connection = sqlCon;
                    try
                    {
                        sqlCon.Open();
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception e)
                    {
                        throw e;
                        return false;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }

                }
            }
        }
    }
}