﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace eRunnerzProject.Control
{
    public class EmployeeAddPermissionQuery
    {
        public int _designationMasterId;
        public int _whocanIADDDesignationID;
        public int _whocanADDMeDesignationID;
        public int _createdById;
        public string _createdByName;
        public DateTime _createdOnActualDate;
        public TimeSpan _createdOnActualTime;
        public int _updatedById;
        public string _updatedByName;
        public DateTime _updatedOnActualDate;
        public TimeSpan _updatedOnActualTime;
        public bool _isDeleted;
        public int DesignationMasterId
        {
            get { return _designationMasterId; }
            set { _designationMasterId = value; }
        }
        public int WhocanIADDDesignationID
        {
            get { return _whocanIADDDesignationID; }
            set { _whocanIADDDesignationID = value; }
        }
        public int WhocanADDMeDesignationID
        {
            get { return _whocanADDMeDesignationID; }
            set { _whocanADDMeDesignationID = value; }
        }
       
        public int CreatedById
        {
            get { return _createdById; }
            set { _createdById = value; }
        }
        public string CreatedByName
        {
            get { return _createdByName; }
            set { _createdByName = value; }
        }
        public DateTime CreatedOnActualDate
        {
            get { return _createdOnActualDate; }
            set { _createdOnActualDate = value; }
        }
        public TimeSpan CreatedOnActualTime
        {
            get { return _createdOnActualTime; }
            set { _createdOnActualTime = value; }
        }
        public int UpdatedById
        {
            get { return _updatedById; }
            set { _updatedById = value; }
        }
        public string UpdatedByName
        {
            get { return _updatedByName; }
            set { _updatedByName = value; }
        }
        public DateTime UpdatedOnActualDate
        {
            get { return _updatedOnActualDate; }
            set { _updatedOnActualDate = value; }
        }
        public TimeSpan UpdatedOnActualTime
        {
            get { return _updatedOnActualTime; }
            set { _updatedOnActualTime = value; }
        }
        public bool isdeleted
        {
            get { return _isDeleted; }
            set { _isDeleted = value; }

        }
       
        public bool SetEmployeeDesignationAddPermission(EmployeeAddPermissionQuery employeeAddPermissionQuery)
        {
            EmployeeDesignationController employeeDesignationController = new EmployeeDesignationController();
            return employeeDesignationController.SetEmployeeDesignationAddPermission(employeeAddPermissionQuery);
        }
        public DataTable GetDesignationAddMasterListByDesignationId(EmployeeAddPermissionQuery employeeAddPermissionQuery)
        {
            EmployeeDesignationController employeeDesignationController = new EmployeeDesignationController();
            return employeeDesignationController.GetDesignationAddMasterListByDesignationId(employeeAddPermissionQuery);
        }
    }
}