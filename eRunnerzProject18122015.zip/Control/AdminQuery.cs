﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace eRunnerzProject.Control
{
    public class AdminQuery
    {
        public int _adminId;

        public string _Username;

        public string _UserPassword;


        public int AdminId
        {
            get { return _adminId; }
            set { _adminId = value; }
        }
        public string Username
        {
            get { return _Username; }
            set { _Username = value; }
        }
        public string UserPassword
        {
            get { return _UserPassword; }
            set { _UserPassword = value; }
        }
        public DataTable AuthorizedUser(AdminQuery adminQuery)
        {
            AdminController adminController = new AdminController();
            return adminController.AuthorizedUser(adminQuery);
        }
        public DataTable GetLoginUser(AdminQuery adminQuery)
        {
            AdminController adminController = new AdminController();
            return adminController.GetLoginUser(adminQuery);
        }
    }
}