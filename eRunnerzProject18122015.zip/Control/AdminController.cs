﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;



namespace eRunnerzProject.Control
{
    public class AdminController
    {
        string conn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        public DataTable AuthorizedUser(AdminQuery adminQuery)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "AuthorizedUser";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@username",adminQuery.Username);
                    cmd.Parameters.AddWithValue("@UserPassword", adminQuery.UserPassword);

                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        return dt;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }
        public DataTable GetLoginUser(AdminQuery adminQuery)
        {
            using (SqlConnection sqlCon = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "GetLoginUser";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AdminId", adminQuery.AdminId);
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        return dt;
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
            }
        }
    }
}