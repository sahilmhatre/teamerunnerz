﻿using eRunnerzProject.Control;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eRunnerzProject
{
    public partial class ManageDesignation1 : System.Web.UI.Page
    {
        public int _designationMasterId;
        public bool _isEdit;

        public int DesignationMasterId
        {
            get { return _designationMasterId; }
            set { _designationMasterId = value; }
        }

        public bool IsEdit
        {
            get { return _isEdit; }
            set { _isEdit = value; }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["uid"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            if (string.IsNullOrEmpty(Request.QueryString["ID"]))
            {
                Response.Redirect("Login.aspx");
            }
            int id = Convert.ToInt32(Session["uid"]);
            if (!Page.IsPostBack)
            {
                BindDesignationList();
            }
            pnlAddDesignation.Visible = false;
        }
        private void BindDesignationList()
        {
            DataTable dtEmployeeDesignation = new DataTable();
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            dtEmployeeDesignation = empQuery.EmployeeDesignationList();
            dlDesignationList.DataSource = dtEmployeeDesignation;
            dlDesignationList.DataBind();
            if (dlDesignationList.Items.Count == 0)
            {
                lblMessage.Text = "There are no rows found.";
            }
        }

        protected void dlDesignationList_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int DesignationID = Convert.ToInt32(dlDesignationList.DataKeys[e.Item.ItemIndex].ToString());
                hdnDesignationMasterID.Value = DesignationID.ToString();
                DataTable dtDesignation = new DataTable();
                setADDFunction();
                EmployeeDesignationQuery designationquery = new EmployeeDesignationQuery();
                designationquery.DesignationId = DesignationID;
                dtDesignation = designationquery.GetDesignationListByDesignationId(designationquery);
                if (dtDesignation.Rows.Count > 0)
                {
                    txtDEsignationCode.Text = dtDesignation.Rows[0]["DesignationCode"].ToString();
                    txtDesignationName.Text = dtDesignation.Rows[0]["DesignationName"].ToString();
                    designationimg.ImageUrl = "~/" + dtDesignation.Rows[0]["DesignationImage"].ToString();
                    EmployeeAddPermissionQuery employeeQuery = new EmployeeAddPermissionQuery();
                    DataTable dtWhocanAdd = new DataTable();
                    employeeQuery.DesignationMasterId = DesignationID;
                    dtWhocanAdd = employeeQuery.GetDesignationAddMasterListByDesignationId(employeeQuery);
                    if (dtWhocanAdd.Rows.Count > 0)
                    {
                        for (int i = 0; i <= dtWhocanAdd.Rows.Count - 1; i++)
                        {
                            if (dtWhocanAdd.Rows[i]["WhocanIADDDesignationID"] != null)
                            {
                                if (Convert.ToInt32(dtWhocanAdd.Rows[i]["WhocanIADDDesignationID"]) > 0)
                                {
                                    string selectedValue = dtWhocanAdd.Rows[i]["WhocanIADDDesignationID"].ToString();
                                    chkWhoCanIAdd.Items.FindByValue(selectedValue).Selected = true;
                                }
                            }
                            if (dtWhocanAdd.Rows[i]["WhocanADDMeDesignationID"].ToString() != null)
                            {
                                if (Convert.ToInt32(dtWhocanAdd.Rows[i]["WhocanADDMeDesignationID"]) > 0)
                                {
                                    string selectedValue = dtWhocanAdd.Rows[i]["WhocanADDMeDesignationID"].ToString();
                                    chkWhoCanAddList.Items.FindByValue(selectedValue).Selected = true;
                                }
                            }
                        }
                    }
                }
                pnlAddDesignation.Visible = true;
                btnSubmit.Text = "Update";
                pnlDesignationList.Visible = false;
            }
            if (e.CommandName == "delete")
            {
                EmployeeDesignationQuery employeeDesignationQuery = new EmployeeDesignationQuery();
                int DesignationID = Convert.ToInt32(dlDesignationList.DataKeys[e.Item.ItemIndex].ToString());
                employeeDesignationQuery.DesignationId = DesignationID;
                // employeeDesignationQuery.DeleteDesignation(employeeDesignationQuery);
                BindDesignationList();
            }
        }

        protected void ADDDesignation_Click(object sender, ImageClickEventArgs e)
        {
            pnlAddDesignation.Visible = true;
            pnlDesignationList.Visible = false;
            setADDFunction();
        }
        private void setADDFunction()
        {
            SetWhoCanAddME();
            SetWhoCanIAdd();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Session["uid"]);
            string username = "";
            if (Session["Username"] == null)
            {
                DataTable dtAdminQuery = new DataTable();
                AdminQuery adminQuery = new AdminQuery();
                adminQuery.AdminId = id;
                dtAdminQuery = adminQuery.GetLoginUser(adminQuery);
                if (dtAdminQuery.Rows.Count > 0)
                {
                    username = Convert.ToString(dtAdminQuery.Rows[0]["Username"]);
                }
            }
            else
            {
                username = Convert.ToString(Session["Username"]);
            }
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            empQuery.DesignationName = txtDesignationName.Text;
            empQuery.DesignationCode = txtDEsignationCode.Text;
            empQuery.CheckDesignationIsValidOrNot(empQuery);
            DateTime serverTime = DateTime.Now; // gives you current Time in server timeZone
            DateTime utcTime = serverTime.ToUniversalTime(); // convert it to Utc using timezone setting of server computer

            TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime localTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, tzi); // convert from utc to local
            string date = String.Format("{0:yyyy-MM-dd}", localTime);
            string time = String.Format("{0:HH:mm:ss.fffffff}", localTime);
            TimeSpan intervalVal;
            TimeSpan ts = new TimeSpan();
            if (TimeSpan.TryParse(time, out intervalVal))
            {
                string intervalToStr = intervalVal.ToString();

                // Pad the end of the TimeSpan string with spaces if it 
                // does not contain milliseconds.
                int pIndex = intervalToStr.IndexOf(':');
                pIndex = intervalToStr.IndexOf('.', pIndex);
                if (pIndex < 0)
                    intervalToStr += "        ";
                ts = TimeSpan.Parse(intervalToStr);
            }
            DateTime Createddatetime = Convert.ToDateTime(date);

            string name = "";
            EmployeeDesignationQuery empDesignationQuery = new EmployeeDesignationQuery();
            empDesignationQuery.DesignationName = txtDesignationName.Text;
            empDesignationQuery.DesignationCode = txtDEsignationCode.Text;
            DataTable DesignationExist = empDesignationQuery.CheckDesignationIsValidOrNot(empDesignationQuery);
            if (DesignationExist.Rows.Count > 0)
            {
                if (btnSubmit.Text != "Update")
                {
                    if (!string.IsNullOrEmpty(txtDEsignationCode.Text))
                    {
                        if (DesignationExist.Rows[0]["DesignationCode"].ToString() == txtDEsignationCode.Text)
                        {
                            lblMessage.Text = "Designation Code<b> " + txtDEsignationCode.Text + " </b> is already exist";
                            return;
                        }
                    }
                }
                if (btnSubmit.Text != "Update")
                {
                    if (!string.IsNullOrEmpty(txtDesignationName.Text))
                    {
                        if (DesignationExist.Rows[0]["DesignationName"].ToString() == txtDesignationName.Text)
                        {
                            lblMessage.Text = "Designation Name<b> " + txtDesignationName.Text + "</b> is already exist";
                            return;
                        }
                    }
                }
            }
            empQuery.UpdatedById = id;
            empQuery.UpdatedByName = username;
            empQuery.UpdatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
            empQuery.UpdatedOnActualTime = ts;
            empQuery.isdelete = false;
            string imgName = designationImage.FileName;
            //sets the image path
            string imgPath = "DesignationImage/" + imgName;
            if (designationImage.PostedFile != null && designationImage.PostedFile.FileName != "")
            {
                // 10240 KB means 10MB, You can change the value based on your requirement
                designationImage.SaveAs(Server.MapPath(imgPath));
                designationimg.ImageUrl = "~/" + imgPath;
            }
            empDesignationQuery.DesignationImage = imgPath;
            int newid = 0;
            if (btnSubmit.Text == "Submit")
            {
                empQuery.CreatedById = id;
                empQuery.CreatedByName = username;
                empQuery.CreatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                empQuery.CreatedOnActualTime = ts;

                newid = empQuery.InsertDesignation(empQuery, imgPath);
            }
            if (btnSubmit.Text == "Update")
            {
                newid = Convert.ToInt32(hdnDesignationMasterID.Value);
                empQuery.DesignationId = newid;
                empQuery.UpdateDesignation(empQuery, imgPath);
                btnSubmit.Text = "Submit";
            }
            if (newid > 0)
            {
                foreach (ListItem item in chkWhoCanAddList.Items)
                {
                    if (item.Selected)
                    {
                        EmployeeAddPermissionQuery employeeAddPermissionQuery = new EmployeeAddPermissionQuery();
                        employeeAddPermissionQuery.DesignationMasterId = newid;
                        employeeAddPermissionQuery.WhocanADDMeDesignationID = Convert.ToInt32(item.Value);
                        employeeAddPermissionQuery.WhocanIADDDesignationID = 0;
                        employeeAddPermissionQuery.CreatedById = id;
                        employeeAddPermissionQuery.CreatedByName = username;
                        employeeAddPermissionQuery.CreatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.UpdatedById = id;
                        employeeAddPermissionQuery.UpdatedByName = username;
                        employeeAddPermissionQuery.UpdatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.isdeleted = false;
                        employeeAddPermissionQuery.SetEmployeeDesignationAddPermission(employeeAddPermissionQuery);
                    }
                }
                foreach (ListItem item in chkWhoCanIAdd.Items)
                {
                    if (item.Selected)
                    {
                        EmployeeAddPermissionQuery employeeAddPermissionQuery = new EmployeeAddPermissionQuery();
                        employeeAddPermissionQuery.DesignationMasterId = newid;
                        employeeAddPermissionQuery.WhocanADDMeDesignationID = 0;
                        employeeAddPermissionQuery.WhocanIADDDesignationID = Convert.ToInt32(item.Value);
                        employeeAddPermissionQuery.CreatedById = id;
                        employeeAddPermissionQuery.CreatedByName = username;
                        employeeAddPermissionQuery.CreatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.UpdatedById = id;
                        employeeAddPermissionQuery.UpdatedByName = username;
                        employeeAddPermissionQuery.UpdatedOnActualDate = Convert.ToDateTime(Createddatetime.ToShortDateString());
                        employeeAddPermissionQuery.CreatedOnActualTime = ts;
                        employeeAddPermissionQuery.isdeleted = false;
                        employeeAddPermissionQuery.SetEmployeeDesignationAddPermission(employeeAddPermissionQuery);
                    }
                }
                setADDFunction();
                pnlAddDesignation.Visible = false;
            }
            else
            {
                lblMessage.Text = "Sucessfully not updated";
            }
            BindDesignationList();
            pnlDesignationList.Visible = true;
        }
        public void SetWhoCanAddME()
        {
            DataTable sql = new DataTable();
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            sql = empQuery.EmployeeDesignationList();
            if (sql.Rows.Count == 0)
            {
                pnlWhoCanADDMe.Visible = false;
                pnlWhoCanIAdd.Visible = false;
            }
            chkWhoCanAddList.Items.Clear();
            chkWhoCanAddList.RepeatDirection = RepeatDirection.Horizontal;
            foreach (DataRow row in sql.Rows) // Loop over the rows.
            {
                ListItem item = new ListItem();
                item.Text = row["DesignationName"].ToString();
                item.Value = row["DesignationId"].ToString();
                chkWhoCanAddList.Items.Add(item);
            }
        }
        public void SetWhoCanIAdd()
        {
            DataTable sql = new DataTable();
            EmployeeDesignationQuery empQuery = new EmployeeDesignationQuery();
            sql = empQuery.EmployeeDesignationList();
            chkWhoCanIAdd.Items.Clear();
            chkWhoCanIAdd.RepeatDirection = RepeatDirection.Horizontal;
            foreach (DataRow row in sql.Rows) // Loop over the rows.
            {
                ListItem item = new ListItem();
                item.Text = row["DesignationName"].ToString();
                item.Value = row["DesignationId"].ToString();
                chkWhoCanIAdd.Items.Add(item);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            pnlDesignationList.Visible = true;
            pnlAddDesignation.Visible = false;

        }

        protected void lnkViewButton_Click(object sender, EventArgs e)
        {
            string selectedDesignation = "";

            foreach (DataListItem li in dlDesignationList.Items)
            {
                CheckBox cb = li.FindControl("chkdelete") as CheckBox;
                // HiddenField designationId = li.FindControl("hdnDesignationMasterID") as HiddenField;
                int DesignationID = Convert.ToInt32(dlDesignationList.DataKeys[li.ItemIndex].ToString());
                if (cb != null)
                {
                    if (cb.Checked)
                    {
                        if (selectedDesignation != "")
                            selectedDesignation += ", ";
                        selectedDesignation += DesignationID;
                    }
                }
            }
            if (selectedDesignation != "")
            {
                EmployeeDesignationQuery employeeDesignationQuery = new EmployeeDesignationQuery();
                employeeDesignationQuery.DeleteDesignation(selectedDesignation);
                BindDesignationList();
            }
        }

        protected void upload_Click(object sender, EventArgs e)
        {
            StartUpLoad();

            if (designationImage.HasFile)
            {
                string fileName = Path.GetFileName(designationImage.PostedFile.FileName);
                designationImage.PostedFile.SaveAs(Server.MapPath("~/DesignationImage/") + fileName);
                designationimg.ImageUrl = "~/DesignationImage/" + fileName;

                BindDesignationList();
            }
        }
        private void StartUpLoad()
        {
            //get the file name of the posted image
            string imgName = designationImage.FileName;
            //sets the image path
            string imgPath = "DesignationImage/" + imgName;
            //get the size in bytes that

            int imgSize = designationImage.PostedFile.ContentLength;

            //validates the posted file before saving
            if (designationImage.PostedFile != null && designationImage.PostedFile.FileName != "")
            {
                // 10240 KB means 10MB, You can change the value based on your requirement
                if (designationImage.PostedFile.ContentLength > 10240)
                {
                    Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('File is too big.')", true);
                }
                else
                {
                    //then save it to the Folder
                    designationImage.SaveAs(Server.MapPath(imgPath));
                    designationimg.ImageUrl = "~/" + imgPath;
                    Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Image saved!')", true);
                }

            }
        }

        protected void lnkAddDesignation_Click(object sender, EventArgs e)
        {
            pnlAddDesignation.Visible = true;
            pnlDesignationList.Visible = false;
            setADDFunction();
        }

        protected void dlDesignationList_ItemDataBound(object sender, DataListItemEventArgs e)
        {

        }

        protected void btnSerch_Click(object sender, EventArgs e)
        {

        }
    }
}